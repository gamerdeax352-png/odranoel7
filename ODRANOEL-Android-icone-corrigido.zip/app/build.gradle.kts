plugins {
    id("com.android.application")
}

android {
    namespace = "com.odranoel.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.odranoel.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
